#!/bin/sh
/bin/sleep 2
exec /sbin/adbd $*
