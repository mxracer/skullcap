    cat /sbin/dfta > /data/dfta
    chmod 777 /data/dfta
    chown root.root /data/dfta
